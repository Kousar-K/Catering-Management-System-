<footer class = "footer-amp">
<div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 footer-column">
		<div class = "padd">
            <!-- Copyright info -->
				<p class="copy center">Copyright &copy; 2021 | <a href="https://www.campcodes.com/">CampCodes</a> </p>
		</div>
      </div>
    </div>
  </div>
</footer>
<span class="totop"><a href="#"><i class="fa fa-chevron-up"></i></a></span> 