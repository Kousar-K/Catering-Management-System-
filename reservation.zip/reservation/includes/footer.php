<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy">Copyright &copy; 2021 | <a href="#">CampCodes Catering</a> </p>
      </div>
    </div>
  </div>
</footer> 